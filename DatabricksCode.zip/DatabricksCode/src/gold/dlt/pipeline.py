import dlt
from transformations.DimUser import *
from transformations.DimTrack import *
from transformations.DimDate import *
from transformations.FactStream import *
@dlt.table
def test_table():
    return spark.range(10)