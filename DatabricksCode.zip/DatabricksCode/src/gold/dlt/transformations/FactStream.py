import dlt
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

@dlt.table
def factstream_stg():
    return spark.read.table("spotify_cata.silver.factstream")


dlt.create_streaming_table("factstream")


dlt.create_auto_cdc_flow(
  target = "factstream",
  source = "factstream_stg",
  keys = ["stream_id"],
  sequence_by = "stream_timestamp",
  stored_as_scd_type = 1,
  track_history_except_column_list = None,
  name = None,
  once = False
)