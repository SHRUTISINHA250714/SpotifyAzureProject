import dlt
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

@dlt.table
def dimtrack_stg():
    return spark.read.table("spotify_cata.silver.dimtrack")


dlt.create_streaming_table("dimtrack")


dlt.create_auto_cdc_flow(
  target = "dimtrack",
  source = "dimtrack_stg",
  keys = ["track_id"],
  sequence_by = "updated_at",
  stored_as_scd_type = 2,
  track_history_except_column_list = None,
  name = None,
  once = False
)