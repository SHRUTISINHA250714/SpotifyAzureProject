import dlt
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()



@dlt.table

def dimuser_stg():
    return spark.read.table("spotify_cata.silver.dimuser")



# dlt.create_streaming_table("dimuser")


# dlt.create_auto_cdc_flow(
#   target = "dimuser",
#   source = "dimuser_stg",
#   keys = ["user_id"],
#   sequence_by = "updated_at",
#   stored_as_scd_type = 2,
#   track_history_except_column_list = None,
#   name = None,
#   once = False
# )